#include "ChernobogAddRules.h"

#include "llvm/ADT/SmallPtrSet.h"
#include "llvm/Analysis/ValueTracking.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/IR/Instructions.h"

#include <functional>
#include <optional>

using namespace llvm;

namespace deobfuscate095 {
namespace {

static bool hasForbiddenValue(Value *V, unsigned Depth = 0) {
  if (!V || Depth > 24)
    return true;
  if (V->getType()->isVectorTy())
    return true;
  if (isa<FreezeInst, UndefValue, PoisonValue>(V))
    return true;
  auto *I = dyn_cast<Instruction>(V);
  if (!I)
    return false;
  for (Value *Op : I->operands())
    if (hasForbiddenValue(Op, Depth + 1))
      return true;
  return false;
}

static bool isPlainIntegerBinary(const BinaryOperator *BO) {
  return BO && BO->getType()->isIntegerTy() &&
         !BO->getType()->isIntegerTy(1);
}

static bool hasDefinedLeaves(Value *A, Value *B) {
  return A && B && A->getType() == B->getType() &&
         A->getType()->isIntegerTy() && !A->getType()->isIntegerTy(1) &&
         !hasForbiddenValue(A) && !hasForbiddenValue(B);
}

static bool isIntegerConstant(Value *V, uint64_t N) {
  auto *C = dyn_cast<ConstantInt>(V);
  return C && C->getValue() == N;
}

static bool isAllOnes(Value *V) {
  auto *C = dyn_cast<ConstantInt>(V);
  return C && C->getValue().isAllOnes();
}

static BinaryOperator *asBinary(Value *V, Instruction::BinaryOps Op) {
  auto *BO = dyn_cast<BinaryOperator>(V);
  return BO && BO->getOpcode() == Op && isPlainIntegerBinary(BO) ? BO
                                                                    : nullptr;
}

// LLVM bnot is xor V, -1.  Match both operand orders, but nothing with casts
// or a non-canonical mask.
static bool matchNot(Value *V, Value *&Input) {
  auto *Xor = asBinary(V, Instruction::Xor);
  if (!Xor)
    return false;
  if (isAllOnes(Xor->getOperand(0))) {
    Input = Xor->getOperand(1);
    return true;
  }
  if (isAllOnes(Xor->getOperand(1))) {
    Input = Xor->getOperand(0);
    return true;
  }
  return false;
}

static bool matchAddConstant(Value *V, uint64_t N, Value *&Other) {
  auto *Add = asBinary(V, Instruction::Add);
  if (!Add)
    return false;
  if (isIntegerConstant(Add->getOperand(0), N)) {
    Other = Add->getOperand(1);
    return true;
  }
  if (isIntegerConstant(Add->getOperand(1), N)) {
    Other = Add->getOperand(0);
    return true;
  }
  return false;
}

static bool matchUnorderedPair(BinaryOperator *BO, Value *A, Value *B) {
  return BO && ((BO->getOperand(0) == A && BO->getOperand(1) == B) ||
                (BO->getOperand(0) == B && BO->getOperand(1) == A));
}

static unsigned pureDagOperationCount(Value *Root) {
  SmallPtrSet<Value *, 16> Seen;
  std::function<unsigned(Value *)> Count = [&](Value *V) -> unsigned {
    if (!V || !Seen.insert(V).second)
      return 0;
    auto *BO = dyn_cast<BinaryOperator>(V);
    if (!BO)
      return 0;
    return 1 + Count(BO->getOperand(0)) + Count(BO->getOperand(1));
  };
  return Count(Root);
}

struct Match {
  StringRef Name;
  Value *X = nullptr;
  Value *Y = nullptr;
  bool AddTwo = false;
  bool ReturnYPlusOne = false;
};

// (x & y) + (x | y) -> x + y.
static std::optional<Match> matchRule1(Value *Root) {
  auto *Add = asBinary(Root, Instruction::Add);
  if (!Add)
    return std::nullopt;
  for (unsigned I = 0; I != 2; ++I) {
    auto *And = asBinary(Add->getOperand(I), Instruction::And);
    auto *Or = asBinary(Add->getOperand(1 - I), Instruction::Or);
    if (!And || !Or)
      continue;
    Value *X = And->getOperand(0);
    Value *Y = And->getOperand(1);
    if (matchUnorderedPair(Or, X, Y) && hasDefinedLeaves(X, Y))
      return Match{"Add_OllvmRule_1", X, Y, false};
  }
  return std::nullopt;
}

// ~(~x + ~y) + 1 -> x + y + 2.
static std::optional<Match> matchRule2(Value *Root) {
  Value *NotSum = nullptr;
  if (!matchAddConstant(Root, 1, NotSum))
    return std::nullopt;
  Value *Sum = nullptr;
  if (!matchNot(NotSum, Sum))
    return std::nullopt;
  auto *Add = asBinary(Sum, Instruction::Add);
  if (!Add)
    return std::nullopt;
  Value *X = nullptr;
  Value *Y = nullptr;
  if (!matchNot(Add->getOperand(0), X) || !matchNot(Add->getOperand(1), Y) ||
      !hasDefinedLeaves(X, Y))
    return std::nullopt;
  return Match{"Add_OllvmRule_2", X, Y, true};
}

// -(~x + ~y + 2) -> x + y.  LLVM neg is sub 0, V.
static std::optional<Match> matchRule3(Value *Root) {
  auto *Neg = asBinary(Root, Instruction::Sub);
  if (!Neg || !isIntegerConstant(Neg->getOperand(0), 0))
    return std::nullopt;
  Value *NotPair = nullptr;
  if (!matchAddConstant(Neg->getOperand(1), 2, NotPair))
    return std::nullopt;
  auto *Add = asBinary(NotPair, Instruction::Add);
  if (!Add)
    return std::nullopt;
  Value *X = nullptr;
  Value *Y = nullptr;
  if (!matchNot(Add->getOperand(0), X) || !matchNot(Add->getOperand(1), Y) ||
      !hasDefinedLeaves(X, Y))
    return std::nullopt;
  return Match{"Add_OllvmRule_3", X, Y, false};
}

// ~(~x | ~y) + ~(x | ~y) + 1 -> y + 1.
static std::optional<Match> matchRule4(Value *Root) {
  Value *Inner = nullptr;
  if (!matchAddConstant(Root, 1, Inner))
    return std::nullopt;
  auto *Add = asBinary(Inner, Instruction::Add);
  if (!Add)
    return std::nullopt;
  for (unsigned I = 0; I != 2; ++I) {
    Value *FirstOr = nullptr;
    Value *SecondOr = nullptr;
    if (!matchNot(Add->getOperand(I), FirstOr) ||
        !matchNot(Add->getOperand(1 - I), SecondOr))
      continue;
    auto *First = asBinary(FirstOr, Instruction::Or);
    auto *Second = asBinary(SecondOr, Instruction::Or);
    if (!First || !Second)
      continue;
    for (unsigned J = 0; J != 2; ++J) {
      Value *X = nullptr;
      Value *Y = nullptr;
      if (!matchNot(First->getOperand(J), X) ||
          !matchNot(First->getOperand(1 - J), Y))
        continue;
      Value *NotY = nullptr;
      bool SecondMatches =
          (Second->getOperand(0) == X && matchNot(Second->getOperand(1), NotY)) ||
          (Second->getOperand(1) == X && matchNot(Second->getOperand(0), NotY));
      if (SecondMatches && NotY == Y && hasDefinedLeaves(X, Y))
        return Match{"Add_OllvmRule_4", X, Y, false, true};
    }
  }
  return std::nullopt;
}

static std::optional<Match> match(Value *Root) {
  if (auto M = matchRule1(Root)) return M;
  if (auto M = matchRule2(Root)) return M;
  if (auto M = matchRule3(Root)) return M;
  return matchRule4(Root);
}

} // namespace

bool simplifyChernobogAddRules(Function &F, ChernobogAddRuleMetrics &Metrics) {
  SmallVector<Instruction *, 64> Roots;
  for (Instruction &I : instructions(F))
    if (I.getType()->isIntegerTy() && !I.getType()->isIntegerTy(1) &&
        !I.use_empty())
      Roots.push_back(&I);

  bool Changed = false;
  for (Instruction *Root : reverse(Roots)) {
    if (!Root->getParent() || Root->use_empty())
      continue;
    auto M = match(Root);
    if (!M)
      continue;
    const unsigned Before = pureDagOperationCount(Root);
    IRBuilder<> B(Root);
    B.SetCurrentDebugLocation(Root->getDebugLoc());
    Value *Replacement = nullptr;
    if (M->ReturnYPlusOne) {
      Replacement = B.CreateAdd(
          M->Y, ConstantInt::get(Root->getType(), 1),
          "deobf.chernobog.add1");
    } else {
      Replacement = B.CreateAdd(M->X, M->Y, "deobf.chernobog.add");
    }
    if (M->AddTwo)
      Replacement = B.CreateAdd(
          Replacement, ConstantInt::get(Root->getType(), 2),
          "deobf.chernobog.add2");
    Root->replaceAllUsesWith(Replacement);
    Root->eraseFromParent();
    auto &Count = Metrics.Rules[M->Name.str()];
    ++Count.Hits;
    Count.OperationsBefore += Before;
    Count.OperationsAfter += M->AddTwo ? 2 : 1;
    Changed = true;
  }
  return Changed;
}

} // namespace deobfuscate095
